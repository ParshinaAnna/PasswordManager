﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace PasswordManager
{
    public class PasswordManagerCore
    {
        private List<PasswordEntry> _entries;
        private readonly string _filename;
        private string _masterPassword;
        private bool _masterPasswordSet;

        public PasswordManagerCore(string filename, string masterPassword)
        {
            _entries = new List<PasswordEntry>();
            _filename = filename;
            _masterPassword = masterPassword;
            _masterPasswordSet = !string.IsNullOrEmpty(masterPassword);
            LoadFromFile();
        }

        public bool VerifyMasterPassword(string password)
        {
            return password == _masterPassword;
        }

        public void AddEntry(PasswordEntry entry)
        {
            _entries.Add(entry);
            SaveToFile();
        }

        public List<PasswordEntry> GetAllEntries()
        {
            return _entries.ToList();
        }

        public List<PasswordEntry> SearchEntries(string query)
        {
            if (string.IsNullOrEmpty(query))
                return GetAllEntries();

            return _entries.Where(e => e.Service.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0).ToList();
        }

        public bool DeleteEntry(int index)
        {
            if (index >= 0 && index < _entries.Count)
            {
                _entries.RemoveAt(index);
                SaveToFile();
                return true;
            }
            return false;
        }

        public string GenerateStrongPassword(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()";
            Random random = new Random();
            char[] password = new char[length];

            for (int i = 0; i < length; i++)
            {
                password[i] = chars[random.Next(chars.Length)];
            }

            return new string(password);
        }

        public bool IsMasterPasswordSet => _masterPasswordSet;

        public void SetMasterPassword(string password)
        {
            _masterPassword = password;
            _masterPasswordSet = true;
            SaveToFile();
        }

        public int EntryCount => _entries.Count;

        private void LoadFromFile()
        {
            if (!File.Exists(_filename)) return;

            string encryptedData = File.ReadAllText(_filename);
            if (string.IsNullOrEmpty(encryptedData)) return;

            string decryptedData = Encryption.EncryptDecrypt(encryptedData);

            string[] entries = decryptedData.Split(new[] { "\n\n" }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string entryStr in entries)
            {
                if (!string.IsNullOrEmpty(entryStr))
                {
                    _entries.Add(PasswordEntry.FromString(entryStr));
                }
            }
        }

        private void SaveToFile()
        {
            StringBuilder dataToSave = new StringBuilder();
            foreach (var entry in _entries)
            {
                dataToSave.Append(entry.ToString());
                dataToSave.Append("\n");
            }

            string encryptedData = Encryption.EncryptDecrypt(dataToSave.ToString());
            File.WriteAllText(_filename, encryptedData);
        }
    }
}