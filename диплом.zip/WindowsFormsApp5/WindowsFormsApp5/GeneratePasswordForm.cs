﻿using System;
using System.Windows.Forms;

namespace PasswordManager
{
    public partial class GeneratePasswordForm : Form
    {
        private PasswordManagerCore _manager;
        private NumericUpDown _lengthBox;
        private Button _generateBtn;
        private TextBox _resultBox;
        private Button _copyBtn;
        private Button _closeBtn;

        public GeneratePasswordForm(PasswordManagerCore manager)
        {
            _manager = manager;
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Генератор паролей";
            this.Size = new System.Drawing.Size(380, 200);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            Label lengthLabel = new Label();
            lengthLabel.Text = "Длина пароля:";
            lengthLabel.Location = new System.Drawing.Point(20, 20);
            lengthLabel.Size = new System.Drawing.Size(90, 25);

            _lengthBox = new NumericUpDown();
            _lengthBox.Location = new System.Drawing.Point(120, 18);
            _lengthBox.Size = new System.Drawing.Size(60, 23);
            _lengthBox.Minimum = 6;
            _lengthBox.Maximum = 32;
            _lengthBox.Value = 12;

            _generateBtn = new Button();
            _generateBtn.Text = "Сгенерировать";
            _generateBtn.Location = new System.Drawing.Point(195, 17);
            _generateBtn.Size = new System.Drawing.Size(100, 25);
            _generateBtn.Click += OnGenerate;

            _resultBox = new TextBox();
            _resultBox.Location = new System.Drawing.Point(20, 55);
            _resultBox.Size = new System.Drawing.Size(330, 23);
            _resultBox.ReadOnly = true;

            _copyBtn = new Button();
            _copyBtn.Text = "Копировать";
            _copyBtn.Location = new System.Drawing.Point(130, 95);
            _copyBtn.Size = new System.Drawing.Size(90, 30);
            _copyBtn.Click += OnCopy;

            _closeBtn = new Button();
            _closeBtn.Text = "Закрыть";
            _closeBtn.Location = new System.Drawing.Point(230, 95);
            _closeBtn.Size = new System.Drawing.Size(90, 30);
            _closeBtn.Click += (s, e) => this.Close();

            this.Controls.Add(lengthLabel);
            this.Controls.Add(_lengthBox);
            this.Controls.Add(_generateBtn);
            this.Controls.Add(_resultBox);
            this.Controls.Add(_copyBtn);
            this.Controls.Add(_closeBtn);
        }

        private void OnGenerate(object sender, EventArgs e)
        {
            int length = (int)_lengthBox.Value;
            string password = _manager.GenerateStrongPassword(length);
            _resultBox.Text = password;
        }

        private void OnCopy(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(_resultBox.Text))
            {
                Clipboard.SetText(_resultBox.Text);
                MessageBox.Show("Пароль скопирован в буфер обмена!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}