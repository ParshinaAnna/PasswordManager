﻿using System;

namespace PasswordManager
{
    public static class Encryption
    {
        private static char _key = 'K';

        public static string EncryptDecrypt(string data, char key)
        {
            if (string.IsNullOrEmpty(data)) return data;

            char[] result = data.ToCharArray();
            for (int i = 0; i < result.Length; i++)
            {
                result[i] = (char)(result[i] ^ key);
            }
            return new string(result);
        }

        public static string EncryptDecrypt(string data)
        {
            return EncryptDecrypt(data, _key);
        }

        public static void SetKey(char key) => _key = key;
        public static char GetKey() => _key;
    }
}