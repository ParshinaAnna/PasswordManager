﻿using System;
using System.Windows.Forms;

namespace PasswordManager
{
    public partial class MainForm : Form
    {
        private PasswordManagerCore _manager;
        private DataGridView _dataGridView;
        private TextBox _searchTextBox;
        private Button _searchButton;
        private Button _addButton;
        private Button _deleteButton;
        private Button _generateButton;
        private Button _copyButton;
        private Button _refreshButton;
        private StatusStrip _statusStrip;
        private ToolStripStatusLabel _statusLabel;

        public MainForm()
        {
            InitializeComponent();
            ShowMasterPasswordDialog();
            RefreshEntries();
        }

        private void InitializeComponent()
        {
            this.Text = "Менеджер паролей";
            this.Size = new System.Drawing.Size(900, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MinimumSize = new System.Drawing.Size(800, 500);

            // Панель поиска
            Panel searchPanel = new Panel { Dock = DockStyle.Top, Height = 40, Padding = new Padding(5) };

            Label searchLabel = new Label { Text = "Поиск:", Location = new System.Drawing.Point(10, 10), Size = new System.Drawing.Size(50, 25) };
            _searchTextBox = new TextBox { Location = new System.Drawing.Point(60, 8), Size = new System.Drawing.Size(200, 23) };
            _searchTextBox.Text = "Введите название сервиса...";
            _searchTextBox.Enter += (s, e) => { if (_searchTextBox.Text == "Введите название сервиса...") _searchTextBox.Text = ""; };
            _searchTextBox.Leave += (s, e) => { if (string.IsNullOrWhiteSpace(_searchTextBox.Text)) _searchTextBox.Text = "Введите название сервиса..."; }; _searchButton = new Button { Text = "Найти", Location = new System.Drawing.Point(270, 7), Size = new System.Drawing.Size(80, 30) };
            _searchButton.Click += OnSearch;

            searchPanel.Controls.AddRange(new Control[] { searchLabel, _searchTextBox, _searchButton });

            // DataGridView для отображения паролей
            _dataGridView = new DataGridView
            {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };

            _dataGridView.Columns.Add("Service", "Сервис");
            _dataGridView.Columns.Add("Username", "Логин");
            _dataGridView.Columns.Add("Password", "Пароль");
            _dataGridView.Columns.Add("Note", "Заметка");

            _dataGridView.Columns["Password"].Width = 100;

            // Панель кнопок
            Panel buttonPanel = new Panel { Dock = DockStyle.Bottom, Height = 50, Padding = new Padding(5) };

            _addButton = new Button { Text = "➕ Добавить пароль", Size = new System.Drawing.Size(130, 35), Location = new System.Drawing.Point(10, 8) };
            _deleteButton = new Button { Text = "🗑 Удалить", Size = new System.Drawing.Size(100, 35), Location = new System.Drawing.Point(150, 8) };
            _generateButton = new Button { Text = "🔑 Генератор", Size = new System.Drawing.Size(100, 35), Location = new System.Drawing.Point(260, 8) };
            _copyButton = new Button { Text = "📋 Копировать", Size = new System.Drawing.Size(100, 35), Location = new System.Drawing.Point(370, 8) };
            _refreshButton = new Button { Text = "🔄 Обновить", Size = new System.Drawing.Size(100, 35), Location = new System.Drawing.Point(480, 8) };

            _addButton.Click += OnAddPassword;
            _deleteButton.Click += OnDeletePassword;
            _generateButton.Click += OnGeneratePassword;
            _copyButton.Click += OnCopyPassword;
            _refreshButton.Click += OnRefresh;

            buttonPanel.Controls.AddRange(new Control[] { _addButton, _deleteButton, _generateButton, _copyButton, _refreshButton });

            // Статусная строка
            _statusStrip = new StatusStrip();
            _statusLabel = new ToolStripStatusLabel("Готов");
            _statusStrip.Items.Add(_statusLabel);

            // Добавление элементов на форму
            this.Controls.Add(_dataGridView);
            this.Controls.Add(searchPanel);
            this.Controls.Add(buttonPanel);
            this.Controls.Add(_statusStrip);
        }

        private void ShowMasterPasswordDialog()
        {
            Form dialog = new Form();
            dialog.Text = "Мастер-пароль";
            dialog.Size = new System.Drawing.Size(350, 150);
            dialog.StartPosition = FormStartPosition.CenterParent;
            dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
            dialog.MaximizeBox = false;
            dialog.MinimizeBox = false;

            Label label = new Label { Text = "Введите мастер-пароль:", Location = new System.Drawing.Point(20, 20), Size = new System.Drawing.Size(150, 25) };
            TextBox passwordBox = new TextBox { Location = new System.Drawing.Point(20, 50), Size = new System.Drawing.Size(250, 23), PasswordChar = '*' };
            Button okButton = new Button { Text = "OK", Location = new System.Drawing.Point(120, 85), Size = new System.Drawing.Size(75, 30), DialogResult = DialogResult.OK };
            Button cancelButton = new Button { Text = "Отмена", Location = new System.Drawing.Point(205, 85), Size = new System.Drawing.Size(75, 30), DialogResult = DialogResult.Cancel };

            dialog.Controls.AddRange(new Control[] { label, passwordBox, okButton, cancelButton });

            string masterPassword = "";
            bool firstRun = !System.IO.File.Exists("passwords.dat");

            if (firstRun)
            {
                MessageBox.Show("Первый запуск! Установите мастер-пароль.", "Установка пароля", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                masterPassword = passwordBox.Text;
                if (string.IsNullOrEmpty(masterPassword))
                {
                    MessageBox.Show("Мастер-пароль не может быть пустым!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                    return;
                }
            }
            else
            {
                Application.Exit();
                return;
            }

            _manager = new PasswordManagerCore("passwords.dat", masterPassword);

            if (!_manager.IsMasterPasswordSet)
            {
                _manager.SetMasterPassword(masterPassword);
            }
            else if (!_manager.VerifyMasterPassword(masterPassword))
            {
                MessageBox.Show("Неверный мастер-пароль!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
        }

        private void RefreshEntries()
        {
            _dataGridView.Rows.Clear();
            var entries = _manager.GetAllEntries();

            foreach (var entry in entries)
            {
                _dataGridView.Rows.Add(entry.Service, entry.Username, entry.MaskedPassword, entry.Note);
            }

            _statusLabel.Text = $"Всего паролей: {entries.Count}";
        }

        private void OnSearch(object sender, EventArgs e)
        {
            string query = _searchTextBox.Text;
            var results = _manager.SearchEntries(query);

            _dataGridView.Rows.Clear();
            foreach (var entry in results)
            {
                _dataGridView.Rows.Add(entry.Service, entry.Username, entry.MaskedPassword, entry.Note);
            }

            _statusLabel.Text = $"Найдено записей: {results.Count}";
        }

        private void OnAddPassword(object sender, EventArgs e)
        {
            using (AddPasswordForm dialog = new AddPasswordForm(_manager))
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    RefreshEntries();
                    _statusLabel.Text = "Пароль успешно добавлен";
                }
            }
        }

        private void OnDeletePassword(object sender, EventArgs e)
        {
            if (_dataGridView.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите запись для удаления", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int index = _dataGridView.SelectedRows[0].Index;

            if (MessageBox.Show("Удалить выбранную запись?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                _manager.DeleteEntry(index);
                RefreshEntries();
                _statusLabel.Text = "Запись удалена";
            }
        }

        private void OnGeneratePassword(object sender, EventArgs e)
        {
            using (GeneratePasswordForm dialog = new GeneratePasswordForm(_manager))
            {
                dialog.ShowDialog();
            }
        }

        private void OnCopyPassword(object sender, EventArgs e)
        {
            if (_dataGridView.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите запись для копирования пароля", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int index = _dataGridView.SelectedRows[0].Index;
            var entries = _manager.GetAllEntries();

            if (index < entries.Count)
            {
                Clipboard.SetText(entries[index].Password);
                _statusLabel.Text = "Пароль скопирован в буфер обмена";
                MessageBox.Show("Пароль скопирован!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void OnRefresh(object sender, EventArgs e)
        {
            _searchTextBox.Clear();
            RefreshEntries();
            _statusLabel.Text = "Список обновлен";
        }
    }
}