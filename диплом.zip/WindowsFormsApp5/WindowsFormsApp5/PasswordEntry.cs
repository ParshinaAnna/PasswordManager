﻿using System;

namespace PasswordManager
{
    public class PasswordEntry
    {
        public string Service { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Note { get; set; }

        // Всегда возвращает ****, независимо от длины пароля
        public string MaskedPassword => "****";

        public PasswordEntry() { }

        public PasswordEntry(string service, string username, string password, string note)
        {
            Service = service;
            Username = username;
            Password = password;
            Note = note;
        }

        public override string ToString()
        {
            return $"{Service}\n{Username}\n{Password}\n{Note}\n";
        }

        public static PasswordEntry FromString(string data)
        {
            var lines = data.Split(new[] { '\n' }, StringSplitOptions.None);
            if (lines.Length >= 4)
            {
                return new PasswordEntry
                {
                    Service = lines[0],
                    Username = lines[1],
                    Password = lines[2],
                    Note = lines[3]
                };
            }
            return new PasswordEntry();
        }
    }
}