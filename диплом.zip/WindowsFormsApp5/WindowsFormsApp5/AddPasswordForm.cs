﻿using System;
using System.Windows.Forms;

namespace PasswordManager
{
    public partial class AddPasswordForm : Form
    {
        private PasswordManagerCore _manager;
        private TextBox _serviceBox;
        private TextBox _usernameBox;
        private TextBox _passwordBox;
        private TextBox _noteBox;
        private Button _genButton;
        private Button _okButton;
        private Button _cancelButton;

        public AddPasswordForm(PasswordManagerCore manager)
        {
            _manager = manager;
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Добавить пароль";
            this.Size = new System.Drawing.Size(450, 350);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            Label serviceLabel = new Label();
            serviceLabel.Text = "Сервис:";
            serviceLabel.Location = new System.Drawing.Point(20, 20);
            serviceLabel.Size = new System.Drawing.Size(80, 25);

            _serviceBox = new TextBox();
            _serviceBox.Location = new System.Drawing.Point(110, 18);
            _serviceBox.Size = new System.Drawing.Size(290, 23);

            Label usernameLabel = new Label();
            usernameLabel.Text = "Логин:";
            usernameLabel.Location = new System.Drawing.Point(20, 55);
            usernameLabel.Size = new System.Drawing.Size(80, 25);

            _usernameBox = new TextBox();
            _usernameBox.Location = new System.Drawing.Point(110, 53);
            _usernameBox.Size = new System.Drawing.Size(290, 23);

            Label passwordLabel = new Label();
            passwordLabel.Text = "Пароль:";
            passwordLabel.Location = new System.Drawing.Point(20, 90);
            passwordLabel.Size = new System.Drawing.Size(80, 25);

            _passwordBox = new TextBox();
            _passwordBox.Location = new System.Drawing.Point(110, 88);
            _passwordBox.Size = new System.Drawing.Size(220, 23);
            _passwordBox.PasswordChar = '*';

            _genButton = new Button();
            _genButton.Text = "Сгенерировать";
            _genButton.Location = new System.Drawing.Point(335, 87);
            _genButton.Size = new System.Drawing.Size(65, 25);
            _genButton.Click += OnGeneratePassword;

            Label noteLabel = new Label();
            noteLabel.Text = "Заметка:";
            noteLabel.Location = new System.Drawing.Point(20, 125);
            noteLabel.Size = new System.Drawing.Size(80, 25);

            _noteBox = new TextBox();
            _noteBox.Location = new System.Drawing.Point(110, 123);
            _noteBox.Size = new System.Drawing.Size(290, 100);
            _noteBox.Multiline = true;

            _okButton = new Button();
            _okButton.Text = "OK";
            _okButton.Location = new System.Drawing.Point(240, 240);
            _okButton.Size = new System.Drawing.Size(80, 30);
            _okButton.DialogResult = DialogResult.OK;

            _cancelButton = new Button();
            _cancelButton.Text = "Отмена";
            _cancelButton.Location = new System.Drawing.Point(330, 240);
            _cancelButton.Size = new System.Drawing.Size(80, 30);
            _cancelButton.DialogResult = DialogResult.Cancel;

            _okButton.Click += OnOk;

            this.Controls.Add(serviceLabel);
            this.Controls.Add(_serviceBox);
            this.Controls.Add(usernameLabel);
            this.Controls.Add(_usernameBox);
            this.Controls.Add(passwordLabel);
            this.Controls.Add(_passwordBox);
            this.Controls.Add(_genButton);
            this.Controls.Add(noteLabel);
            this.Controls.Add(_noteBox);
            this.Controls.Add(_okButton);
            this.Controls.Add(_cancelButton);
        }

        private void OnGeneratePassword(object sender, EventArgs e)
        {
            string password = _manager.GenerateStrongPassword(12);
            _passwordBox.Text = password;
        }

        private void OnOk(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_serviceBox.Text) || string.IsNullOrEmpty(_usernameBox.Text) || string.IsNullOrEmpty(_passwordBox.Text))
            {
                MessageBox.Show("Заполните все обязательные поля!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.DialogResult = DialogResult.None;
                return;
            }

            var entry = new PasswordEntry(_serviceBox.Text, _usernameBox.Text, _passwordBox.Text, _noteBox.Text);
            _manager.AddEntry(entry);
        }
    }
}